unchecked definitions:

take_unchecked(X,Y).
put_unchecked(X,Y).
move_unchecked(X).
transfer_unchecked(X,Y).
make_unchecked(X).





checked definitions:
take(X).
put(X,Y).
move(X).
transfer(X,Y).
make(X).



Other defintions:
look(X).
study(X).
inventory.
